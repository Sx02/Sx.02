#!/bin/bash
echo $red 
 echo ""----------------------------------------------------------------------------- ""
echo " This Script is written by Techz viral india Yt Channel. enjoy"
echo "---------------------------------------------------------------------------------"

echo "007"
echo "007"
echo "007"
echo "."

echo  "#####################################"
echo   "  SUBSCRIBE    TECHZ    VIRAL     INDIA      "               
 echo   " FOR TECH &  ETHICAL HACKING VIDEOS "                                                                    
echo   "####################################"

echo "007"
echo "007"
echo "007"

echo "."

apt update -y                      #update in progress
apt install python -y           #installation......
apt install python2 -y
apt install ruby -y 
apt install git -y

echo  "#####################################"
echo   "  SUBSCRIBE    TECHZ    VIRAL     INDIA      "               
 echo   " FOR TECH &  ETHICAL HACKING VIDEOS "                                                                    
echo   "####################################"

apt install php -y 
apt install perl -y
apt install nmap -y

echo  "#####################################"
echo   "  SUBSCRIBE    TECHZ    VIRAL     INDIA      "               
 echo   " FOR TECH &  ETHICAL HACKING VIDEOS "                                                                    
echo   "####################################"

apt install bash -y
apt install clang -y
apt install jq -y
apt install macchanger -y

echo  "#####################################"
echo   "  SUBSCRIBE    TECHZ    VIRAL     INDIA      "               
 echo   " FOR TECH &  ETHICAL HACKING VIDEOS "                                                                    
echo   "####################################"

apt install nano -y
apt install curl -y
apt install tar -y
apt install zip -y

echo  "#####################################"
echo   "  SUBSCRIBE    TECHZ    VIRAL     INDIA      "               
 echo   " FOR TECH &  ETHICAL HACKING VIDEOS "                                                                    
echo   "####################################"

apt install unzip -y
apt install tor -y 
apt install sudo -y
apt install wget -y

echo  "#####################################"
echo   "  SUBSCRIBE    TECHZ    VIRAL     INDIA      "               
 echo   " FOR TECH &  ETHICAL HACKING VIDEOS "                                                                    
echo   "####################################"

apt install wcalc -y 
apt install openssl
apt install bmon -y

echo  "#####################################"
echo   "  SUBSCRIBE    TECHZ    VIRAL     INDIA      "               
 echo   " FOR TECH &  ETHICAL HACKING VIDEOS "                                                                    
echo   "####################################"

echo " If You Connected To Internet Then  "
echo " YOUR PACKAGES IS INSTALLED SUCCESSFULLY "

exit